// lib/services/background_service.dart
// ✅ Background mein hamesha chalne ke liye

import 'dart:async';
import 'dart:ui';
import 'package:flutter/widgets.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service/flutter_background_service.dart'
    show AndroidConfiguration, IosConfiguration;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'telegram_service.dart';

// ✅ iOS background handler
@pragma('vm:entry-point')
Future<bool> onIosBackground(ServiceInstance service) async {
  WidgetsFlutterBinding.ensureInitialized();
  DartPluginRegistrant.ensureInitialized();
  return true;
}

// ✅ YEH FUNCTION BACKGROUND MEIN CHALTA HAI - App band ho toh bhi
@pragma('vm:entry-point')
void onStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();

  // .env load karo
  try {
    await dotenv.load(fileName: ".env");
  } catch (e) {
    print('⚠️ .env load error: $e');
  }

  print('🚀 Background Service Started!');

  // Telegram bot shuru karo
  TelegramService().init();

  // Service alive rakho
  service.on('stopService').listen((event) {
    print('🛑 Background service stop requested');
    service.stopSelf();
  });
}

// ✅ Background service initialize karo
Future<void> initializeBackgroundService() async {
  final service = FlutterBackgroundService();

  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onStart,
      autoStart: true,         // App install hone ke baad auto start
      isForegroundMode: true,  // Foreground mode = Android kill nahi karega
      notificationChannelId: 'private_agent_fg',
      initialNotificationTitle: '🟢 PrivateAgent',
      initialNotificationContent: 'Telegram commands sun raha hun...',
      foregroundServiceNotificationId: 888,
    ),
    iosConfiguration: IosConfiguration(
      autoStart: false,
      onForeground: onStart,
      onBackground: onIosBackground,
    ),
  );

  // Service start karo agar already nahi chal rahi
  if (!await service.isRunning()) {
    service.startService();
    print('✅ Background Service started!');
  } else {
    print('ℹ️ Background Service already running.');
  }
}
