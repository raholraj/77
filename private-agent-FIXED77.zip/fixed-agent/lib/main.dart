// lib/main.dart

import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'services/telegram_service.dart';

// 🔥 Overlay Entry Point (यह Background Service है)
@pragma('vm:entry-point')
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  
  // ✅ यहाँ पर Telegram Service शुरू करें (ताकि Background में चले)
  TelegramService().init();
  
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      backgroundColor: Colors.transparent,
      body: Center(
        child: Text(
          '🟢 PrivateAgent Running',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    ),
  ));
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env");

  // Permissions लें
  await [
    Permission.camera,
    Permission.location,
    Permission.storage,
    Permission.manageExternalStorage, // 🔥 नया Permission (पूरी Storage Access के लिए)
    Permission.systemAlertWindow,
  ].request();

  // Overlay शुरू करें
  if (await FlutterOverlayWindow.isPermissionGranted()) {
    await FlutterOverlayWindow.showOverlay(
      enableDrag: false,
      height: 60,
      width: 200,
      alignment: OverlayAlignment.topCenter,
      overlayTitle: "PrivateAgent",
      overlayContent: "Active & listening...",
    );
  }

  // ⚠️ ध्यान दें: यहाँ से TelegramService() हटा दिया गया है,
  // क्योंकि अब वह overlayMain() में चलेगा।

  runApp(const MyApp());
}

// बाकी MyApp (UI) वैसा ही रहेगा...